<?php $__env->startSection('title', $movie->title . ' - CineWave'); ?>

<?php $__env->startSection('content'); ?>
<div class="pb-20">
    <!-- Movie Backdrop Hero -->
    <div class="relative h-[70vh]">
        <img src="<?php echo e($movie->backdrop); ?>" 
             alt="<?php echo e($movie->title); ?>" 
             class="w-full h-full object-cover">
        <div class="absolute inset-0 gradient-overlay"></div>
        
        <div class="absolute bottom-0 left-0 p-12 max-w-4xl">
            <h1 class="text-5xl font-bold mb-4"><?php echo e($movie->title); ?></h1>
            <div class="flex items-center gap-4 mb-4 flex-wrap">
                <span class="px-3 py-1 bg-primary rounded text-sm font-bold"><?php echo e($movie->rating); ?></span>
                <span><?php echo e($movie->year); ?></span>
                <span><?php echo e($movie->duration); ?></span>
                <?php if(is_array($movie->genre)): ?>
                    <?php $__currentLoopData = $movie->genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="px-3 py-1 bg-gray-800 rounded text-sm"><?php echo e($genre); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="flex gap-4 mb-6">
                <a href="<?php echo e(route('movie.play', $movie->id)); ?>" 
                   class="px-8 py-3 bg-primary hover:bg-secondary rounded font-bold transition flex items-center gap-2">
                    Play
                </a>
                <button onclick="toggleWatchlist('<?php echo e($movie->id); ?>')" id="watchlist-btn"
                        class="px-8 py-3 bg-gray-800/80 hover:bg-gray-700 rounded font-bold transition">
                    <span id="watchlist-text"><?php echo e($inWatchlist ? '- Remove from List' : '+ Add to My List'); ?></span>
                </button>
            </div>
        </div>
    </div>

    <!-- Movie Details -->
    <div class="px-12 py-8">
        <div class="grid md:grid-cols-3 gap-8">
            <!-- Main Content -->
            <div class="md:col-span-2">
                <h2 class="text-2xl font-bold mb-4">Description</h2>
                <p class="text-lg text-gray-300 mb-8"><?php echo e($movie->description); ?></p>

                <?php if($movie->cast && is_array($movie->cast)): ?>
                <div class="mb-8">
                    <h3 class="text-xl font-bold mb-4">Cast</h3>
                    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                        <?php $__currentLoopData = $movie->cast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center gap-3">
                            <img src="<?php echo e($actor['photo'] ?? 'https://via.placeholder.com/64'); ?>" 
                                 alt="<?php echo e($actor['name'] ?? 'Actor'); ?>" 
                                 class="w-16 h-16 rounded-full object-cover">
                            <div>
                                <p class="font-semibold"><?php echo e($actor['name'] ?? 'Unknown'); ?></p>
                                <p class="text-sm text-gray-400"><?php echo e($actor['character'] ?? 'Character'); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div>
                <div class="bg-gray-900 rounded-lg p-6">
                    <h3 class="text-lg font-bold mb-4">Details</h3>
                    <dl class="space-y-3">
                        <?php if($movie->director): ?>
                        <div>
                            <dt class="text-gray-400 text-sm">Director</dt>
                            <dd class="font-semibold"><?php echo e($movie->director); ?></dd>
                        </div>
                        <?php endif; ?>
                        <div>
                            <dt class="text-gray-400 text-sm">Release Year</dt>
                            <dd class="font-semibold"><?php echo e($movie->year); ?></dd>
                        </div>
                        <div>
                            <dt class="text-gray-400 text-sm">Duration</dt>
                            <dd class="font-semibold"><?php echo e($movie->duration); ?></dd>
                        </div>
                        <div>
                            <dt class="text-gray-400 text-sm">Genres</dt>
                            <dd class="font-semibold"><?php echo e(is_array($movie->genre) ? implode(', ', $movie->genre) : $movie->genre); ?></dd>
                        </div>
                    </dl>
                </div>
            </div>
        </div>

        <!-- More Like This -->
        <?php if($relatedMovies->isNotEmpty()): ?>
        <div class="mt-12">
            <h2 class="text-2xl font-bold mb-6">More Like This</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <?php $__currentLoopData = $relatedMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedMovie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('components.movie-card', ['movie' => $relatedMovie], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function toggleWatchlist(movieId) {
    const btn = document.getElementById('watchlist-btn');
    const text = document.getElementById('watchlist-text');
    
    fetch(`/movie/${movieId}/watchlist`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            text.textContent = data.inWatchlist ? '- Remove from List' : '+ Add to My List';
            
            // Show notification
            const notification = document.createElement('div');
            notification.className = 'fixed top-4 right-4 bg-primary text-white px-6 py-3 rounded shadow-lg z-50';
            notification.textContent = data.message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to update watchlist');
    });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rizky\Documents\Coding\CineWave\resources\views/movie/show.blade.php ENDPATH**/ ?>