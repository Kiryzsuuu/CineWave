

<?php $__env->startSection('title', 'Admin - Manage Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-8">
        <h1 class="text-4xl font-bold">Manage Users</h1>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="px-6 py-3 bg-gray-700 hover:bg-gray-600 rounded font-bold transition">
            Back to Dashboard
        </a>
    </div>

    <?php if(session('success')): ?>
    <div class="bg-green-600 text-white px-6 py-4 rounded mb-6">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="bg-red-600 text-white px-6 py-4 rounded mb-6">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>

    <div class="bg-gray-900 rounded-lg overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-800">
                <tr>
                    <th class="px-6 py-4 text-left">Name</th>
                    <th class="px-6 py-4 text-left">Email</th>
                    <th class="px-6 py-4 text-left">Role</th>
                    <th class="px-6 py-4 text-left">Registered</th>
                    <th class="px-6 py-4 text-left">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b border-gray-800 hover:bg-gray-800/50">
                    <td class="px-6 py-4 font-semibold"><?php echo e($user->name); ?></td>
                    <td class="px-6 py-4"><?php echo e($user->email); ?></td>
                    <td class="px-6 py-4">
                        <?php if($user->is_admin): ?>
                        <span class="px-3 py-1 bg-primary rounded text-sm">Admin</span>
                        <?php else: ?>
                        <span class="px-3 py-1 bg-gray-700 rounded text-sm">User</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4"><?php echo e($user->created_at->format('M d, Y')); ?></td>
                    <td class="px-6 py-4">
                        <div class="flex gap-2">
                            <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" 
                               class="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded text-sm transition">
                                Edit
                            </a>
                            <?php if($user->id != auth()->id()): ?>
                            <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" 
                                  onsubmit="return confirm('Are you sure you want to delete this user?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="px-4 py-2 bg-red-600 hover:bg-red-700 rounded text-sm transition">
                                    Delete
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rizky\Documents\Coding\CineWave\resources\views/admin/users/index.blade.php ENDPATH**/ ?>