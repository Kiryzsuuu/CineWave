

<?php $__env->startSection('title', 'Community - CineWave'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-4xl font-bold mb-8">Community</h1>
    
    <div class="text-center py-20">
        <p class="text-xl text-gray-400">Community feature coming soon!</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rizky\Documents\Coding\CineWave\resources\views/community/index.blade.php ENDPATH**/ ?>