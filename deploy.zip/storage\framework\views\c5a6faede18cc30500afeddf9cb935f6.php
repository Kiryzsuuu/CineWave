

<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8 max-w-2xl">
    <div class="flex justify-between items-center mb-8">
        <h1 class="text-4xl font-bold">Edit User</h1>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="px-6 py-3 bg-gray-700 hover:bg-gray-600 rounded font-bold transition">
            Back
        </a>
    </div>

    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST" class="bg-gray-900 rounded-lg p-8">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="space-y-6">
            <div>
                <label class="block text-sm font-bold mb-2">Name</label>
                <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" required
                       class="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded focus:border-primary focus:outline-none">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label class="block text-sm font-bold mb-2">Email</label>
                <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required
                       class="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded focus:border-primary focus:outline-none">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label class="block text-sm font-bold mb-2">New Password (leave empty to keep current)</label>
                <input type="password" name="password"
                       class="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded focus:border-primary focus:outline-none">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="flex items-center">
                <input type="checkbox" name="is_admin" id="is_admin" value="1" <?php echo e(old('is_admin', $user->is_admin) ? 'checked' : ''); ?>

                       class="w-4 h-4 text-primary bg-gray-800 border-gray-700 rounded focus:ring-primary">
                <label for="is_admin" class="ml-2 text-sm font-bold">Admin Access</label>
            </div>
        </div>

        <div class="flex gap-4 mt-8">
            <button type="submit" class="px-8 py-3 bg-primary hover:bg-secondary rounded font-bold transition">
                Update User
            </button>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="px-8 py-3 bg-gray-700 hover:bg-gray-600 rounded font-bold transition">
                Cancel
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rizky\Documents\Coding\CineWave\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>